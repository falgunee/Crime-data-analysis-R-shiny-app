a<-read.csv("Crime by place of occurrence.csv")
View(a)
Id<-c(1:26)
a<-cbind(a,Id)
nrow(a)
library(dplyr)
library(tidyr)
library(ggplot2)
library(scales)
library(ggrepel)
library(forcats)
data<-a[-26,]
View(data)
colnames(data)
data1<-data %>%mutate(per=Total_Dacoity_Cases.reported/sum(Total_Dacoity_Cases.reported))   
data$States.UTs
data$Total_Dacoity_Cases.reported
ggplot(data , aes(x=States.UTs,y=Total_Dacoity_Cases.reported,fill=States.UTs))+geom_bar(stat="identity")+
  ggtitle("Total Dacoity cases Reported by State") + xlab("State") + 
  ylab("Number of cases reported")+geom_text(aes(label=Total_Dacoity_Cases.reported))


