library(ggplot2)
df <- read.csv("OVERVIEW.csv", header=TRUE, sep=",")
View(df)
#withoutlabel
ggplot(df,aes(x=reorder(States,Total_Crime),Total_Crime)) +geom_col(fill = "red") +coord_flip() +labs(title = "Top Crime Commited in India ,State wise distribution ", x = "States", y = "Total Crime")
#with label
ggplot(df,aes(x=reorder(,Total_Crime),Total_Crime)) +geom_col(fill = "red") +coord_flip() +labs(title = "Top Crime Commited in India ,State wise distribution ", x = "States", y = "Total Crime")+  geom_label(aes(label = Total_Crime), size = 2)

       